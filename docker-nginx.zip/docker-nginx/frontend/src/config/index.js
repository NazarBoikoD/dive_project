export default {
  services: {
    host: process.env.REACT_APP_SERVICES_HOST
  }
}